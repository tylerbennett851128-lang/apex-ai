r__roll(int&);
