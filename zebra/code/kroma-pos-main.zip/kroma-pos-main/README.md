<h1 align="center">
  <img src="./public/logo.png" alt="KromaPOS Logo" width="200"/>
  <h1>KromaPOS</h1>
  <p>Empowering Local Commerce — Anywhere, Anytime.</p>
</h1>

**KromaPOS** is an open-source, offline-first Point of Sale (POS) system built with **React** and **Electron**, designed to empower small and medium-sized businesses in Cambodia and beyond. With a sleek interface, modern tech stack, and local-first mindset, KromaPOS makes selling easy—whether you're online or completely offline.

---

## 🌟 Features

- ⚡ **Offline-first** – Operates smoothly without an internet connection
- 🛍️ **Sales & Inventory Management**
- 🧾 **Receipt Printing Support**
- 🧑‍💼 **Multi-user Login & Role-based Access**
- 📦 **Product and Category Management**
- 📊 **Sales Reporting Dashboard**
- 🌐 **Multi-language Support (Coming Soon)**
- 🔄 **Sync to Cloud (Optional Future Feature)**

---

## 📦 Tech Stack

- **Frontend**: React, Tailwind CSS
- **Desktop Shell**: Electron
- **Database (Offline)**: SQLite
- **Data Sync (Planned)**: FastAPI or Firebase
- **State Management**: Zustand or Redux Toolkit

---

## 🛠️ Installation

### Prerequisites

- Node.js (v18+)
- Git

### Clone and Install

```bash
git clone https://github.com/vicheanath/kroma-pos.git
cd kroma-pos
npm install
```

### Environment Setup

Create a `.env.local` file in the root directory with the following:

```bash
# NextAuth Secret (required)
# Generate with: openssl rand -base64 32
NEXTAUTH_SECRET=your-generated-secret-here

# Google OAuth (optional, for cloud sync)
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
```

**Note**: For development, a default secret is provided, but you should set `NEXTAUTH_SECRET` in production.

# Screenshots

![KromaPOS BarCode Generator](./docs/barcode-generator.png)
![KromaPOS Barcode](./docs/barcode.png)
![KromaPOS Inventory](./docs/inventory.png)
![KromaPOS Receipt Design](./docs/receipt-desing.png)
![KromaPOS Report](./docs/report.png)
![KromaPOS Sale](./docs/sale.png)
