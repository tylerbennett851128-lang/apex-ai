"""# =========================================================================.

#  Copyright Joost van Griethuysen
#
#  Licensed under the 3-Clause BSD-License (the "License");
#  you may not use this file except in compliance with the License.
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
# ========================================================================

# =========================================================================
# This file is adapted from Slicer Case Iterator and is maintained by Flywheel.
#
# The original author, Joost van Griethuysen, is not responsible for any
# changes made to this file or any problems with its use.
#
# Likewise, Flywheel is not responsible for maintaining the original or changes
# that may occur.
# =========================================================================
"""
import ast
import json
import os
import shutil
import tempfile
from collections import deque
from pathlib import Path

import ctk
import flywheel
import qt
import slicer
import vtk
from fw_pyqt_management.config import Config
from fw_pyqt_management.fw_container_items import (
    AcquisitionItem,
    AnalysisItem,
    ContainerParentModel,
    FileItem,
    ProjectItem,
    SessionItem,
    SubjectItem,
)

from . import IteratorBase

# ------------------------------------------------------------------------------
# FlywheelCaseIterator CSV iterator Widget
# ------------------------------------------------------------------------------

source_dir = Path(__file__).parents[1]
resource_dir = source_dir / "Resources"

FLYWHEEL_CONFIG_DIR = Path.home() / ".config" / "flywheel"
CONFIG_PATH = FLYWHEEL_CONFIG_DIR / "fw_connect.json"
CONFIG_DEFAULTS = json.load((resource_dir / "config_defaults.json").open())


class FWCaseTableIteratorWidget(IteratorBase.IteratorWidgetBase):
    """This class governs the widget interface for Flywheel Case Iterator."""

    fw_client = None

    def __init__(self):
        """Initialize the Flywheel Case Table Iterator Widget class."""
        super().__init__()

        self.tableNode = None
        self.tableStorageNode = None

    # ------------------------------------------------------------------------------
    def setup(self):
        """Setup the widget for display.

        Returns:
            QGroupBox: A reference to the widget to display in the extension
        """
        # Get config
        self.config = Config(CONFIG_PATH, CONFIG_DEFAULTS)

        # Declare Cache path
        if self.config.get("cache_dir"):
            self.cache_dir = Path(self.config.get("cache_dir"))
        else:
            self.cache_dir = (
                Path(self.config["CachePath"]) / self.config["CacheDirName"]
            )

        self.paired_file_types = json.load(
            (resource_dir / "paired_file_types.json").open()
        )
        self.instance = ""

        self.CsvInputGroupBox = qt.QGroupBox("FW CSV input for local files")
        CsvInputLayout = qt.QFormLayout(self.CsvInputGroupBox)

        # Give a line_edit and label for the API key
        self.apiKeyCollapsibleGroupBox = ctk.ctkCollapsibleGroupBox()
        self.apiKeyCollapsibleGroupBox.setTitle("API Key Entry")

        CsvInputLayout.addWidget(self.apiKeyCollapsibleGroupBox)
        apiKeyFormLayout = qt.QFormLayout(self.apiKeyCollapsibleGroupBox)

        #
        # api Key Text Box
        #
        self.apiKeyTextLabel = qt.QLabel("API Key:")
        apiKeyFormLayout.addWidget(self.apiKeyTextLabel)
        self.apiKeyTextBox = qt.QLineEdit()
        self.apiKeyTextBox.setEchoMode(qt.QLineEdit.Password)

        apiKeyFormLayout.addWidget(self.apiKeyTextBox)
        self.connectAPIButton = qt.QPushButton("Connect Flywheel")
        self.connectAPIButton.enabled = True
        apiKeyFormLayout.addWidget(self.connectAPIButton)

        self.logAlertTextLabel = qt.QLabel("")
        apiKeyFormLayout.addWidget(self.logAlertTextLabel)

        #
        # Input CSV Path
        #
        self.batchTableSelector = slicer.qMRMLNodeComboBox()
        self.batchTableSelector.nodeTypes = ["vtkMRMLTableNode"]
        self.batchTableSelector.addEnabled = True
        self.batchTableSelector.selectNodeUponCreation = True
        self.batchTableSelector.renameEnabled = True
        self.batchTableSelector.removeEnabled = True
        self.batchTableSelector.noneEnabled = False
        self.batchTableSelector.setMRMLScene(slicer.mrmlScene)
        self.batchTableSelector.toolTip = (
            "Select the table representing the cases to process."
        )
        CsvInputLayout.addRow(self.batchTableSelector)

        self.batchTableView = slicer.qMRMLTableView()
        CsvInputLayout.addRow(self.batchTableView)
        self.batchTableView.show()

        #
        # Parameters Area
        #
        self.parametersCollapsibleButton = ctk.ctkCollapsibleButton()
        self.parametersCollapsibleButton.text = "Parameters"
        CsvInputLayout.addWidget(self.parametersCollapsibleButton)

        # Layout within the dummy collapsible button
        parametersFormLayout = qt.QFormLayout(self.parametersCollapsibleButton)

        #
        # Input parameters GroupBox
        #

        self.inputParametersGroupBox = qt.QGroupBox("Input parameters")
        parametersFormLayout.addRow(self.inputParametersGroupBox)

        inputParametersFormLayout = qt.QFormLayout(self.inputParametersGroupBox)

        #
        # Root Path
        #
        self.rootSelector = qt.QLineEdit()
        self.rootSelector.text = "parent._id"
        self.rootSelector.toolTip = (
            "Location of the root directory to load from, "
            "or the column name specifying said "
            "directory in the input CSV"
        )
        inputParametersFormLayout.addRow("Parent Container ID", self.rootSelector)

        #
        # Image Path
        #
        self.imageSelector = qt.QLineEdit()
        self.imageSelector.text = "file.name"
        self.imageSelector.toolTip = (
            "Name of the column specifying main image files in input CSV"
        )
        inputParametersFormLayout.addRow("Image Filename", self.imageSelector)

        #
        # Connect Event Handlers
        #
        self.connectAPIButton.connect("clicked(bool)", self.on_connect_api_pushed)

        self.batchTableSelector.connect(
            "nodeActivated(vtkMRMLNode*)", self.onChangeTable
        )
        self.imageSelector.connect("textEdited(QString)", self.onChangeImageColumn)

        self.segmentationParametersGroupBox = qt.QGroupBox(
            "Mask interaction parameters"
        )
        parametersFormLayout.addRow(self.segmentationParametersGroupBox)

        segmentationParametersFormLayout = qt.QFormLayout(
            self.segmentationParametersGroupBox
        )

        #
        # Auto-redirect to SegmentEditor
        #
        self.chkAutoRedirect = qt.QCheckBox()
        self.chkAutoRedirect.checked = False
        self.chkAutoRedirect.toolTip = (
            'Automatically switch module to "SegmentEditor" when each case is loaded'
        )
        segmentationParametersFormLayout.addRow(
            "Go to Segment Editor", self.chkAutoRedirect
        )

        #
        # Save masks
        #
        self.chkSaveMasks = qt.QCheckBox()
        self.chkSaveMasks.checked = False
        self.chkSaveMasks.toolTip = (
            "save all initially loaded masks when proceeding to next case"
        )
        segmentationParametersFormLayout.addRow("Save loaded masks", self.chkSaveMasks)

        #
        # Save new masks
        #
        self.chkSaveNewMasks = qt.QCheckBox()
        self.chkSaveNewMasks.checked = True
        self.chkSaveNewMasks.toolTip = (
            "save all newly generated masks when proceeding to next case"
        )
        segmentationParametersFormLayout.addRow("Save new masks", self.chkSaveNewMasks)

        return self.CsvInputGroupBox

    # ------------------------------------------------------------------------------
    def enter(self):
        """Override for the enter function of the widget."""
        self.onChangeTable()

    # ------------------------------------------------------------------------------
    def is_valid(self):
        """Check for the validity of the current configuration.

        On success, this indicates that a batch can be started. Enabling/Disabling the
        "start batch" button depends on the result True/False.

        Returns:
            boolean: Validity of the current setting, if true the batch may be started.
        """
        return (
            self.batchTableSelector.currentNodeID != ""
            and self.imageSelector.text != ""
            and self.fw_client is not None
        )

    # ------------------------------------------------------------------------------
    def startBatch(self, reader=None):
        """Function to start the batch.

        In the derived class, this should store relevant nodes to keep track of
        important data.

        Args:
            reader (str, optional): The string representing the reader.Defaults to None.

        Returns:
            Iterator: Iterator class instance defining the dataset to iterate over.
                      Iterator contains functions for loading and storing a case.
        """
        self.tableNode = self.batchTableSelector.currentNode()
        self.tableStorageNode = self.tableNode.GetStorageNode()

        columnMap = self._parseConfig()

        self._iterator = FWCaseTableIteratorLogic(
            self.tableNode, columnMap, self.cache_dir / self.instance
        )
        self._iterator.registerEventListener(
            CsvTableEventHandler(
                go_to_segment_editor=self.chkAutoRedirect.checked,
                reader=reader,
                saveNew=self.chkSaveNewMasks.checked,
                saveLoaded=self.chkSaveMasks.checked,
            )
        )
        return self._iterator

    # ------------------------------------------------------------------------------
    def cleanupBatch(self):
        """Clean up files and settings of the current batch."""
        if self._iterator and self._iterator.currentIdx is not None:
            self._iterator.closeCase()
        self.tableNode = None
        self.tableStorageNode = None
        self._iterator = None

    # ------------------------------------------------------------------------------

    def get_cli_api_key(self):
        """Get the api key from a successful CLI loging to Flywheel.

        e.g. `fw login <api-key>`

        Which puts the api key in the config file at ~/.config/flywheel/user.json

        Returns:
            str: api key or None
        """
        user_json_path = Path.home() / ".config" / "flywheel" / "user.json"
        api_key = None
        if user_json_path.exists():
            with user_json_path.open() as f:
                user_json = json.load(f)
                api_key = user_json.get("key")

        return api_key

    def get_fw_client(self):
        """Retrieve the Flywheel Client.

        This function retrieves the Flywheel Client from various sources:
        - If the api-key is entered in the text box, this will be used.
        - Else, If an api-key is in the config file, this will be used.
        - Else, If an api-key is in the CLI-generated ~/.config/flywheel/user.json,
          this will be used.
        - Else, None is returned.

        Returns:
            str: The api-key or None
        """
        fw_client = None
        # Load values from config file. This will be a str or None.
        api_key = self.config.get("api_key")

        # Instantiate and connect widgets ...
        # if valid, the api key in the text box will overide the config contents
        if self.apiKeyTextBox.text:
            if api_key != self.apiKeyTextBox.text:
                # reset config file
                for key in ["group", "project"]:
                    if self.config.get(key):
                        del self.config[key]
                api_key = self.apiKeyTextBox.text
        elif not api_key:
            api_key = self.get_cli_api_key()

        if api_key:
            fw_client = flywheel.Client(api_key)
            self.config["api_key"] = api_key

        return fw_client

    def on_connect_api_pushed(self):
        """Connect to a Flywheel instance for valid api-key."""
        try:
            qt.QApplication.setOverrideCursor(qt.Qt.WaitCursor)

            FWCaseTableIteratorWidget.fw_client = self.get_fw_client()

            if self.fw_client is None:
                raise Exception("Could not find a valid api-key. Please try again.")

            fw_user = self.fw_client.get_current_user()["email"]
            fw_site = self.fw_client.get_config()["site"]["api_url"]
            self.instance = fw_site.split("/")[2].split(":")[0]

            self.logAlertTextLabel.setText(
                f"You are logged in as {fw_user} to {fw_site}"
            )

            # Set cache directory with instance
            # self.tree_management.set_cache_dir(self.cache_dir / self.instance)

            # Clear out any other instance's data from Slicer before proceeding.
            slicer.mrmlScene.Clear(0)
            self.batchTableSelector.setCurrentNodeID("")
            self.onChangeTable()
        except Exception as exp:
            self.logger.exception(exp)
            self.logger.error("Could not connect to Flywheel instance.")
            message = (
                "Please check your API key, your "
                "internet connection, and the Flywheel instance you are trying to "
                "connect to."
            )
            self.logger.error(message)
            slicer.util.errorDisplay(message)

        finally:
            qt.QApplication.restoreOverrideCursor()

    # ------------------------------------------------------------------------------
    def onChangeTable(self):
        """Execute on table selection from the batchTableSelector qMRMLNodeComboBox."""
        self.batchTableView.setMRMLTableNode(self.batchTableSelector.currentNode())
        self.validate()

    # ------------------------------------------------------------------------------
    def onChangeImageColumn(self):
        """Execute on change to Image Filename."""
        self.validate()

    # ------------------------------------------------------------------------------
    def _parseConfig(self):
        """This parses the user input in the selectors of different column types.

        Returns:
            dict: Mapping requested columns to the correct keys
        """
        columnMap = {}

        if self.rootSelector.text != "":
            columnMap["container_id"] = str(self.rootSelector.text).strip()

        assert self.imageSelector.text != ""  # Image column is a required column
        columnMap["image"] = str(self.imageSelector.text).strip()

        return columnMap


# ------------------------------------------------------------------------------
# FlywheelCaseIterator CSV iterator
# ------------------------------------------------------------------------------


class FWCaseTableIteratorLogic(IteratorBase.IteratorLogicBase):
    """Flywheel Case Table Iterator Logic class."""

    source_model = None

    def __init__(self, tableNode, columnMap, cache_dir):
        """Initialize the Flywheel Case Table Iterator Logic class.

        Args:
            tableNode (vtkMRMLTableNode): The loaded TableNode.
            columnMap (dict): Columns to be used for the iterator.
            cache_dir (Path): Path to the cache directory.
        """
        super().__init__()
        assert tableNode is not None, "No table selected! Cannot instantiate batch"
        self.fw_client = FWCaseTableIteratorWidget.fw_client
        self.cache_dir = cache_dir
        self.source_model = ContainerParentModel()
        self.source_model.set_cache_dir(self.cache_dir)
        FWCaseTableIteratorLogic.source_model = self.source_model
        # If the table was loaded from a file,
        # get the directory containing the file as reference for relative paths
        tableStorageNode = tableNode.GetStorageNode()
        if tableStorageNode is not None and tableStorageNode.GetFileName() is not None:
            self.csv_dir = os.path.dirname(tableStorageNode.GetFileName())
        else:  # Table did not originate from a file
            self.csv_dir = None

        # Get the actual table contained in the MRML node
        self.batchTable = tableNode.GetTable()

        # Dictionary holding the specified (and found) columns from the tableNode
        self.caseColumns = self._getColumns(columnMap)

        self.caseCount = (
            self.batchTable.GetNumberOfRows()
        )  # Counter equalling the total number of cases

    # ------------------------------------------------------------------------------
    def __del__(self):
        """Delete the Flywheel Case Table Iterator Logic class."""
        super().__del__()
        self.logger.debug("Destroying CSV Table Iterator")
        self.batchTable = None
        self.caseColumns = None

    # ------------------------------------------------------------------------------
    def _getColumns(self, columnMap):
        """Retrieve validated columns from the columnMap that exist in the loaded table.

        Errors are created if they are not found in the loaded table.

        Args:
            columnMap (dict): Dictionary of the table columns used.

        Returns:
            dict: A validated key/value set of columns that exist in the table.
        """
        caseColumns = {}

        # Declare temporary function to parse out the user config and get the correct
        # columns from the batchTable
        def getColumn(key):
            """Get a column with a single value.

            Columns with multiple values have been removed.

            Args:
                key (str): Key of column to retrieve.
            """
            col = None
            if key in columnMap:
                col = self.batchTable.GetColumnByName(columnMap[key])
                assert col is not None, 'Unable to find column "%s" (key %s)' % (
                    columnMap[key],
                    key,
                )
            caseColumns[key] = col

        # Special case: Check if there is a column "patient" or "ID"
        # (used for additional naming of the case during logging)
        patientColumn = self.batchTable.GetColumnByName("patient")
        if patientColumn is None:
            patientColumn = self.batchTable.GetColumnByName("ID")
        if patientColumn is not None:
            caseColumns["patient"] = patientColumn

        # Get the other configurable columns
        getColumn("container_id")
        getColumn("image")

        return caseColumns

    def _download_from_container(self, container_id, file_name):
        """Download file_name from a flywheel container.

        If the file_name is not found in the container an error message is logged and
        a None value is returned.

        Args:
            container_id (str): The id of a flywheel container to download a file from.
            file_name (str): The name of a file within the above container.

        Returns:
            Pathlike or None: Path to the downloaded file. None if it was not found.
        """
        try:
            root_container = self.fw_client.get(container_id)
        except Exception as exp:
            self.logger.error("Could not get container %s", container_id)
            root_container = None

        if not root_container:
            log_msg = (
                f"The container, {container_id}, does not exist on the instance or "
                "you do not have permissions to access it."
            )
            self.logger.error(log_msg)
            return None

        if root_container.container_type == "analysis":
            slicer.util.errorDisplay(
                "Changes to Analysis containers are not "
                "supported by FlywheelCaseIterator."
            )
            return None

        try:
            file_obj = root_container.get_file(file_name)
        except Exception as exp:
            self.logger.error(
                "Could not get file %s from container %s", file_name, container_id
            )
            file_obj = None

        if not file_obj:
            log_msg = (
                f"The file, {file_name}, does not exist on the instance or "
                "you do not have permissions to access it."
            )
            self.logger.error(log_msg)
            return None

        file_item = FileItem(self.source_model, file_obj)

        # If the file is not in the cache, download it
        # An interruption in the connection will cause the file to be downloaded again
        # for up to 5 times. Else `path` will be None.
        path, _ = file_item._add_to_cache()

        if not path:
            return None

        return file_item

    def get_segment_names(self, segmentation_node):
        """Get the names of the segments in a segmentation node.

        Args:
            segmentation_node (vtkMRMLSegmentationNode): The segmentation node to get
                                                         the segment names.

        Returns:
            list: List of the segment names.
        """
        segment_names = []
        segmentation = segmentation_node.GetSegmentation()
        for i in range(segmentation.GetNumberOfSegments()):
            segment_names.append(segmentation.GetNthSegment(i).GetName())

        return segment_names

    def save_case_data_to_instance(self):
        """Save the case data to the image files info.

        Returns:
            dict or None: A dictionary representation of the case data.
        """
        # unpack case data
        im, ma, add_im, add_ma = self.getCaseData()

        # create the template
        template = {"FlywheelCaseIteratorInfo": {}}

        # Record primary image data
        if (im_parent_id := im.GetAttribute("parent_container_id")) and (
            im_name := Path(im.GetStorageNode().GetFileName()).name
        ):
            template["FlywheelCaseIteratorInfo"]["image"] = {
                "parent": im_parent_id,
                "name": im_name,
            }
        else:
            return None

        # record mask data
        if ma:
            if (ma_parent_id := ma.GetAttribute("parent_container_id")) and (
                ma_name := ma.GetAttribute("name")
            ):
                segment_names = self.get_segment_names(ma)
                template["FlywheelCaseIteratorInfo"]["mask"] = {
                    "parent": ma_parent_id,
                    "name": ma_name,
                    "segment_names": segment_names,
                }

        # record additional image data
        # NOTE: additional images will always be an empty list until fully implemented
        if add_im:
            template["FlywheelCaseIteratorInfo"]["additional_images"] = []
            for a_im in add_im:
                if (
                    a_im  # Ensure image is not None
                    and (
                        (a_im_parent_id := a_im.GetAttribute("parent_container_id"))
                        or (  # if from flywheel_connect, attribute in storage node
                            a_im_parent_id := a_im.GetStorageNode().GetAttribute(
                                "parent_container_id"
                            )
                        )
                    )
                    and (a_im_name := Path(a_im.GetStorageNode().GetFileName()).name)
                ):
                    template["FlywheelCaseIteratorInfo"]["additional_images"].append(
                        {"parent": a_im_parent_id, "name": a_im_name}
                    )
                else:
                    self.logger.warning("Additional image is missing parent info.")
                    self.logger.warning("The image will not be included in the case.")
                    self.logger.warning(
                        "The image needs to be loaded from with "
                        "Flywheel Connect Extension."
                    )

        # record additional mask data
        # NOTE: additional masks will always be an empty list until fully implemented
        if add_ma:
            template["FlywheelCaseIteratorInfo"]["additional_masks"] = []
            for a_ma in add_ma:
                if (
                    a_ma  # Ensure mask is not None
                    and (ma_parent_id := a_ma.GetAttribute("parent_container_id"))
                    and (ma_name := a_ma.GetAttribute("name"))
                ):
                    segment_names = self.get_segment_names(a_ma)
                    template["FlywheelCaseIteratorInfo"]["additional_masks"].append(
                        {
                            "parent": ma_parent_id,
                            "name": ma_name,
                            "segment_names": segment_names,
                        }
                    )

        # Save the case data to the image file info if it has changed
        file_obj = self.fw_client.get(im_parent_id).get_file(im_name).reload()
        if file_obj.info != template:
            file_obj.update_info(template)

        return template

    def _get_image(self, case_idx):
        """Get the image from the index.

        Returns the image node and the caseData.

        Args:
            case_idx (int): Integer of the case index.

        Returns:
            tuple: Primary image (Node) and caseData (dict) or (None, None)
        """
        container_id = self._getColumnValue("container_id", case_idx)
        image_file_name = self._getColumnValue("image", case_idx)

        file_item = self._download_from_container(container_id, image_file_name)
        file_path = file_item._get_cache_path() if file_item else None
        file_info = file_item._get_info() if file_path else None

        if file_info is None:
            return None, None

        # Load image
        im_node = (
            self._loadImageNode(file_path.parent, file_path.name) if file_path else None
        )

        if im_node is None:
            return None, None

        # If exists, parse the case data from the image file info
        caseData = file_info.get("FlywheelCaseIteratorInfo", {}) if file_info else {}

        # Set the container_id as an attribute in the reference image node
        im_node.SetAttribute("parent_container_id", container_id)

        return im_node, caseData

    def _get_mask(self, caseData, im_node):
        """Get the mask from the case data.

        Args:
            caseData (dict): A dictionary of the case Data
            im_node (Node): Node of the primary image

        Returns:
            Node or None: The Node of the mask or None if not found.
        """
        if not (mask_data := caseData.get("mask")):
            return None

        if mask_file := self._download_from_container(
            mask_data["parent"], mask_data["name"]
        ):
            mask_file_path = mask_file._get_cache_path()
        else:
            mask_file_path = None

        # If the mask segment labels exist, load them into the mask node
        segment_names = mask_data.get("segment_names", [])
        if mask_file_path is not None:
            ma_node = self._loadMaskNode(
                mask_file_path.parent, mask_file_path.name, im_node, segment_names
            )
            ma_node.SetAttribute("parent_container_id", mask_data["parent"])
            ma_node.SetAttribute("name", mask_data["name"])
        else:
            # Else we want to create a new mask.
            ma_node = None

        return ma_node

    def _get_additional_images(self, caseData):
        """Get the additional images from the case data.

        Args:
            caseData (dict): Dictionary of Case Data.

        Returns:
            list: A list of additional image nodes.
        """
        additionalImageNodes = []
        if add_im_data := caseData.get("additional_images"):
            for image_data in add_im_data:
                if image_data and (
                    image_file := self._download_from_container(
                        image_data["parent"], image_data["name"]
                    )
                ):
                    image_file_path = image_file._get_cache_path()
                else:
                    image_file_path = None
                    self.logger.warning("Image file not found: %s", image_data["name"])
                    self.logger.warning("Removing from case data.")

                add_im_node = (
                    self._loadImageNode(image_file_path.parent, image_file_path.name)
                    if image_file_path
                    else None
                )
                if add_im_node is not None:
                    additionalImageNodes.append(add_im_node)
                    add_im_node.SetAttribute(
                        "parent_container_id", image_data["parent"]
                    )
                    add_im_node.SetAttribute("name", image_data["name"])

        return additionalImageNodes

    def _get_additional_masks(self, caseData, im_node):
        """Get the additional masks from the case data.

        TODO: We may want to associate the additional masks
              with the additional images.

        Args:
            caseData (dict): Dictionary of Case Data.
            im_node (Node): Image Node

        Returns:
            list: List of Nodes
        """
        additionalMaskNodes = []
        if add_ma_data := caseData.get("additional_masks"):
            for mask_data in add_ma_data:
                if mask_data and (
                    mask_file := self._download_from_container(
                        mask_data["parent"], mask_data["name"]
                    )
                ):
                    mask_file_path = mask_file._get_cache_path()
                else:
                    mask_file_path = None
                    self.logger.warning("Mask file not found: %s", mask_data["name"])
                    self.logger.warning("Removing from case data.")

                segment_names = mask_data.get("segment_names", [])
                add_ma_node = (
                    self._loadMaskNode(
                        mask_file_path.parent,
                        mask_file_path.name,
                        im_node,
                        segment_names,
                    )
                    if mask_file_path
                    else None
                )
                if add_ma_node is not None:
                    additionalMaskNodes.append(add_ma_node)
                    add_ma_node.SetAttribute("parent_container_id", mask_data["parent"])
                    add_ma_node.SetAttribute("name", mask_data["name"])

        return additionalMaskNodes

    # ------------------------------------------------------------------------------
    def loadCase(self, case_idx):
        """Load the case from the table indicated by case_idx.

        Args:
            case_idx (int): The index of the desired case in the table.

        Returns:
            boolean: True if the case was loaded successfully.
        """
        assert (
            0 <= case_idx < self.caseCount
        ), "case_idx %d is out of range (n cases: %d)" % (case_idx, self.caseCount)
        try:
            qt.QApplication.setOverrideCursor(qt.Qt.WaitCursor)
            if self.currentIdx is not None:
                self.closeCase()

            if "patient" in self.caseColumns:
                patient = self.caseColumns["patient"].GetValue(case_idx)
                self.logger.info(
                    "Loading patient (%d/%d): %s...",
                    case_idx + 1,
                    self.caseCount,
                    patient,
                )
            else:
                self.logger.info(
                    "Loading case (%d/%d)...", case_idx + 1, self.caseCount
                )

            # TODO: Put in error catching and notification code around this.
            im_node, caseData = self._get_image(case_idx)
            assert im_node is not None, "Failed to load main image"

            # Retrieve the additional images
            additionalImageNodes = self._get_additional_images(caseData)

            # Retrieve the mask
            ma_node = self._get_mask(caseData, im_node)

            # Retrieve the additional masks
            additionalMaskNodes = self._get_additional_masks(caseData, im_node)

            # TODO: Yes, we want to understand this and error catching
            self.setCaseData(
                im_node, ma_node, additionalImageNodes, additionalMaskNodes
            )

            self.currentIdx = case_idx

            self._eventListeners.caseLoaded(self.parameterNode)
            return True
        except Exception as exc:
            self.logger.exception(exc)
            raise exc
        finally:
            qt.QApplication.restoreOverrideCursor()

    def closeCase(self):
        """Close a case by removing the nodes and reseting values.

        On failure, we want to clean up the nodes and reset the values.
        """
        try:
            self._eventListeners.caseAboutToClose(self.parameterNode)
            if caseData := self.parameterNode.GetParameter("CaseData"):
                caseData = ast.literal_eval(caseData)
                _ = self.save_case_data_to_instance()

                self.removeNodeByID(caseData["InputImage_ID"])
                if caseData["InputMask_ID"]:
                    self.removeNodeByID(caseData["InputMask_ID"])

                deque(map(self.removeNodeByID, caseData["Additional_InputImage_IDs"]))
                deque(map(self.removeNodeByID, caseData["Additional_InputMask_IDs"]))
        except Exception as exc:
            self.logger.error("Failed to close case. Cleaning up.")
            self.logger.exception(exc)

        finally:
            # clean up any dangling volume nodes
            deque(
                map(
                    slicer.mrmlScene.RemoveNode,
                    slicer.util.getNodesByClass("vtkMRMLScalarVolumeNode"),
                )
            )
            # clean up the dangling segmentation nodes
            deque(
                map(
                    slicer.mrmlScene.RemoveNode,
                    slicer.util.getNodesByClass("vtkMRMLSegmentationNode"),
                )
            )
            self.setCaseData(None, None, [], [])
            self.currentIdx = None

    def getCaseData(self):
        """Retrieve node from NodeIDs stored in the CaseData of the parameterNode.

        Each node is returned, None, or an empty list.

        TODO: We may want to rethink how this works.  It is a bit of a mess.

        Returns:
            tuple:  image node, mask node, additional image nodes, additional mask nodes
        """
        try:
            # TODO: This is going to depend on saving the parent and file_ids
            #       in the parameter node.
            caseData = eval(self.parameterNode.GetParameter("CaseData"))
            im = slicer.mrmlScene.GetNodeByID(caseData["InputImage_ID"])
            ma = (
                slicer.mrmlScene.GetNodeByID(caseData["InputMask_ID"])
                if caseData["InputMask_ID"]
                else None
            )
            add_im = list(
                map(slicer.mrmlScene.GetNodeByID, caseData["Additional_InputImage_IDs"])
            )
            add_ma = list(
                map(slicer.mrmlScene.GetNodeByID, caseData["Additional_InputMask_IDs"])
            )

            return im, ma, add_im, add_ma
        except Exception:
            return [None, None, [], []]

    def setCaseData(self, im_node, ma_node, additionalImageNodes, additionalMaskNodes):
        """Set the case data in the parameter node.

        Args:
            im_node (Node): The image node.
            ma_node (Node): The mask node.
            additionalImageNodes (list): List of additional image nodes.
            additionalMaskNodes (list): List of additional mask nodes.
        """
        self.parameterNode.SetParameter(
            "CaseData",
            {
                "InputImage_ID": im_node.GetID(),
                "InputMask_ID": ma_node.GetID() if ma_node else None,
                "Additional_InputImage_IDs": [
                    node.GetID() for node in additionalImageNodes
                ],
                "Additional_InputMask_IDs": [
                    node.GetID() for node in additionalMaskNodes
                ],
            }.__str__()
            if im_node  # if im_node is None, then we are closing the case
            else "",
        )

    # ------------------------------------------------------------------------------
    def _getColumnValue(self, colName, idx, is_list=False):
        """Retreive the value of a table column at row idx.

        Args:
            colName (str): Name of a validated table column.
            idx (int): The row number of the table.
            is_list (bool, optional): If the column is a list. Defaults to False.

        Returns:
            str: The value of the column specified at by colName and row idx.
        """
        if colName not in self.caseColumns or self.caseColumns[colName] is None:
            if is_list:
                return []
            else:
                return None
        if is_list:
            return [col.GetValue(idx) for col in self.caseColumns[colName]]
        else:
            return self.caseColumns[colName].GetValue(idx)

    # ------------------------------------------------------------------------------
    def _buildPath(self, caseRoot, fname):
        """Build filepath.

        Args:
            caseRoot (str): Parent directory
            fname (str): Name of the file to put in th caseRoot directory.

        Returns:
            str: Fully qualified file path.
        """
        if fname is None or fname == "":
            return None

        if os.path.isabs(fname):
            return fname

        # Add the caseRoot if specified
        if caseRoot is not None:
            fname = os.path.join(caseRoot, fname)

            # Check if the caseRoot is an absolute path
            if os.path.isabs(fname):
                return fname

        # Add the csv_dir to the path if it is not None (loaded table)
        if self.csv_dir is not None:
            fname = os.path.join(self.csv_dir, fname)

        return os.path.abspath(fname)

    # ------------------------------------------------------------------------------
    def _loadImageNode(self, root, fname):
        """Load an Image Node from root/fname.

        Args:
            root (str): Directory of the file.
            fname (str): Name of the file.

        Returns:
            Node: The 3D Slicer Node representing the loaded image.
        """
        im_path = self._buildPath(root, fname)
        if im_path is None:
            return None

        if not os.path.isfile(im_path):
            self.logger.warning("Volume file %s does not exist, skipping...", fname)
            return None

        # TODO: Enable loading of other file types, such as DICOM, and have their
        #       segmentation files saved as the same type.

        # If the file is not a NIfTI file, skip it
        if not im_path.endswith(".nii") and not im_path.endswith(".nii.gz"):
            self.logger.error("Volume file %s is not a NIfTI file, skipping...", fname)
            return None

        im_node = slicer.util.loadVolume(im_path)
        if not im_node:
            self.logger.warning("Failed to load " + im_path)
            return None

        # Use the file basename as the name for the loaded volume
        nodename = os.path.splitext(os.path.basename(im_path))[0]
        nodename = (
            nodename.replace(".nii", "") if nodename.endswith(".nii") else nodename
        )
        im_node.SetName(nodename)

        return im_node

    # ------------------------------------------------------------------------------
    def _loadMaskNode(self, root, fname, ref_im=None, segment_names=[]):
        """Load a mask node specified at root/fname that is associated with ref_im.

        The mask is loaded as segmentations or converted from Label Maps (NIfTI).

        Args:
            root (str): Directory where the mask is located.
            fname (str): The file name of the mask.
            ref_im (Node, optional): The node of the loaded reference image.
                                     Defaults to None.
            segment_names (list, optional): List of segment names to load.
                                            Defaults to [].

        Returns:
            Node or None: The 3D Slicer Node of the mask or None if failed to load.
        """
        ma_path = self._buildPath(root, fname)
        if ma_path is None:
            return None

        # Check if the file actually exists
        if not os.path.isfile(ma_path):
            self.logger.warning(
                "Segmentation file %s does not exist, skipping...", fname
            )
            return None

        # Determine if file is segmentation based on extension
        isSegmentation = os.path.splitext(ma_path)[0].endswith(".seg")
        # Try to load the mask
        if isSegmentation:
            self.logger.debug("Loading segmentation")
            ma_node = slicer.util.loadSegmentation(ma_path)
        else:
            self.logger.debug("Loading labelmap and converting to segmentation")
            # If not segmentation, then load as labelmap then convert to segmentation
            ma_node = slicer.util.loadLabelVolume(ma_path)
            if ma_node:
                # Only try to make a segmentation node if Slicer loaded the label map
                seg_node = slicer.vtkMRMLSegmentationNode()
                # Need to add the segmentation node to the scene before adding segments
                slicer.mrmlScene.AddNode(seg_node)
                # Add a segment for each name in segment_names
                for name in segment_names:
                    seg_node.GetSegmentation().AddEmptySegment(name)

                # Create a string array or None if no segment names
                segment_ids = vtk.vtkStringArray() if segment_names else None

                for name in segment_names:
                    segment_ids.InsertNextValue(name)

                seg_node.SetReferenceImageGeometryParameterFromVolumeNode(ref_im)
                segmentation_logic = slicer.modules.segmentations.logic()
                if segment_ids:
                    # Add the labelmap to the segmentation node with the specified names
                    load_success = segmentation_logic.ImportLabelmapToSegmentationNode(
                        ma_node, seg_node, segment_ids
                    )
                else:
                    load_success = segmentation_logic.ImportLabelmapToSegmentationNode(
                        ma_node, seg_node
                    )
                slicer.mrmlScene.RemoveNode(ma_node)
                ma_node = seg_node

                # Add a storage node for this segmentation node
                file_base, ext = os.path.splitext(ma_path)
                store_node = seg_node.CreateDefaultStorageNode()
                slicer.mrmlScene.AddNode(store_node)
                seg_node.SetAndObserveStorageNodeID(store_node.GetID())

                store_node.SetFileName("%s.seg%s" % (file_base, ext))

                # UnRegister the storage node to prevent a memory leak
                store_node.UnRegister(None)

        if not load_success:
            self.logger.warning("Failed to load " + ma_path)
            return None

        # Use the file basename as the name for the newly loaded segmentation node
        nodename = os.path.splitext(os.path.basename(ma_path))[0]
        nodename = (
            nodename.replace(".nii", "") if nodename.endswith(".nii") else nodename
        )
        if isSegmentation:
            # split off .seg
            nodename = os.path.splitext(nodename)[0]
        ma_node.SetName(nodename)
        # Saving the node resets GetModifiedSinceRead() to False
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            slicer.util.saveNode(ma_node, str(tmp_path / "temp.seg.nrrd"))
        return ma_node


class CsvTableEventHandler(IteratorBase.IteratorEventHandlerBase):
    """The CSV Table Event Handler for iterating through the loaded table."""

    def __init__(
        self, go_to_segment_editor, reader=None, saveNew=False, saveLoaded=False
    ):
        """Initialize the CSV Table Event Handler.

        Args:
            go_to_segment_editor (bool): Go to the segment editor after loading.
            reader (str, optional): The name of the reader. Defaults to None.
            saveNew (bool, optional): Save new images and masks. Defaults to False.
            saveLoaded (bool, optional): Save changes to loaded. Defaults to False.
        """
        super().__init__()

        # Some variables that control the output
        # (formatting and control of discarding/saving)
        self.go_to_segment_editor = go_to_segment_editor
        self.reader = reader
        self.saveNew = saveNew
        self.saveLoaded = saveLoaded
        self.fw_client = FWCaseTableIteratorWidget.fw_client

    @staticmethod
    def _rotateToVolumePlanes(referenceVolume):
        """Snap three planes to views of the reference image.

        Args:
            referenceVolume (Node): The reference image to view in the panes.
        """
        sliceNodes = slicer.util.getNodes("vtkMRMLSliceNode*")
        for name, node in sliceNodes.items():
            node.RotateToVolumePlane(referenceVolume)
        # Snap to IJK to try and avoid rounding errors
        sliceLogics = slicer.app.layoutManager().mrmlSliceLogics()
        numLogics = sliceLogics.GetNumberOfItems()
        for n in range(numLogics):
            l = sliceLogics.GetItemAsObject(n)
            l.SnapSliceOffsetToIJK()

    def onCaseLoaded(self, caller, *args, **kwargs):
        """Tasks performed on loading a case.

        Args:
            caller (Iterator): The iterator class loading the case.
        """
        try:
            im, ma, add_im, _ = caller.getCaseData()

            # Set the slice viewers to the correct volumes
            for sliceWidgetName in ["Red", "Green", "Yellow"]:
                logic = (
                    slicer.app.layoutManager()
                    .sliceWidget(sliceWidgetName)
                    .sliceLogic()
                    .GetSliceCompositeNode()
                )
                logic.SetBackgroundVolumeID(im.GetID())
                if len(add_im) > 0:
                    logic.SetForegroundVolumeID(add_im[0].GetID())

            # Snap the viewers to the slice plane of the main image
            self._rotateToVolumePlanes(im)

            # the following code should go somewhere in a separate class
            # including the save part
            if self.go_to_segment_editor:
                if slicer.util.selectedModule() != "SegmentEditor":
                    slicer.util.selectModule("SegmentEditor")
                else:
                    slicer.modules.SegmentEditorWidget.enter()

                # Explicitly set the segmentation and master volume nodes
                segmentEditorWidget = (
                    slicer.modules.segmenteditor.widgetRepresentation().self().editor
                )
                if ma is not None:
                    segmentEditorWidget.setSegmentationNode(ma)
                segmentEditorWidget.setSourceVolumeNode(im)

        except Exception as e:
            if slicer.app.majorVersion * 100 + slicer.app.minorVersion < 411:
                e = e.message
            self.logger.warning("Error loading new case: %s", e)
            self.logger.debug("", exc_info=True)

    def onCaseAboutToClose(self, caller, *args, **kwargs):
        """Perform tasks before a case is closed.

        Save mask, additional images, and additional masks to Flywheel instance.

        Args:
            caller (Iterator): The iterator parsing through the table.
        """
        caseData = caller.getCaseData()
        image, mask, additionalImages, additionalMasks = caseData
        if self.saveLoaded:
            # The primary image should not change and we will not save any changes

            # save the mask
            if mask is not None:
                self.save_mask_to_container(mask, self.reader, caseData)
            # warn the user if there is a deleted mask.
            # This will occur as a None value in the list
            if None in additionalMasks:
                self.logger.warning(
                    "An additional mask has been delete from 3D Slicer."
                )
                self.logger.warning("This will be removed from the case data.")
                self.logger.warning("The segmentation will remain in Flywheel.")

            # clear out the possibility of a deleted additional mask
            additionalMasks = [a_ma for a_ma in additionalMasks if a_ma]
            for a_ma in additionalMasks:
                self.save_mask_to_container(a_ma, self.reader, caseData)

            # Check for removed additional images, warn the user, and remove them
            if None in additionalImages:
                self.logger.warning(
                    "An additional image has been deleted from 3D Slicer."
                )
                self.logger.warning("This will be removed from the case data.")
                self.logger.warning("The image will remain in Flywheel.")
            additionalImages = [a_im for a_im in additionalImages if a_im]

        if self.saveNew:
            # if the current mask is None, look for a mask in the scene
            if not mask:
                nodes = slicer.util.getNodesByClass("vtkMRMLSegmentationNode")
                # if masks are found, assign the first one to the current mask
                if nodes:
                    mask = nodes[0]
                    self.save_mask_to_container(mask, self.reader, caseData)

            # find all segmentation nodes that are not the current mask
            # if the current mask is None, assign it to the first in the node list
            nodes = [
                n
                for n in slicer.util.getNodesByClass("vtkMRMLSegmentationNode")
                if n not in additionalMasks and n != mask
            ]

            deque(
                map(
                    lambda n: self.save_mask_to_container(n, self.reader, caseData),
                    nodes,
                )
            )

            # TODO: This is really clunky and needs to be refactored for new masks and
            #       additional masks.

            # check all of the masks for bounds
            bounds = [0.0] * 6
            bounds_list = []
            for n in nodes:
                n.GetBounds(bounds)
                bounds_list.append(bounds != [1.0, -1.0] * 3 and bounds[0] < 1e100)

            # if there is no mask, assign the first mask in the list
            if bounds_list:
                if not mask:
                    first_index = bounds_list.index(True)
                    mask = nodes[first_index] if first_index >= 0 else None
                    additionalMasks.extend(
                        [
                            nodes[i]
                            for i in range(len(nodes))
                            if i != first_index and bounds_list[i]
                        ]
                    )
                else:
                    additionalMasks.extend(
                        [nodes[i] for i in range(len(nodes)) if bounds_list[i]]
                    )

            # find and save any additional images to the container
            nodes = [
                n
                for n in slicer.util.getNodesByClass("vtkMRMLScalarVolumeNode")
                if n not in additionalImages and n != image and n is not None
            ]
            additionalImages.extend(nodes)

            caller.setCaseData(image, mask, additionalImages, additionalMasks)

        if slicer.util.selectedModule() == "SegmentEditor":
            slicer.modules.SegmentEditorWidget.exit()

    def cache_uploaded_files(self, parent_container, uploaded_files):
        """Retain uploaded files in cache.

        Args:
            parent_container (Container): Parent container of uploaded files
            uploaded_files (list): List of file paths.
        """
        if parent_container.container_type == "project":
            parent_container_item = ProjectItem(
                FWCaseTableIteratorLogic.source_model, parent_container
            )
        elif parent_container.container_type == "subject":
            parent_container_item = SubjectItem(
                FWCaseTableIteratorLogic.source_model, parent_container
            )
        elif parent_container.container_type == "session":
            parent_container_item = SessionItem(
                FWCaseTableIteratorLogic.source_model, parent_container
            )
        elif parent_container.container_type == "acquisition":
            parent_container_item = AcquisitionItem(
                FWCaseTableIteratorLogic.source_model, parent_container
            )
        elif parent_container.container_type == "analysis":
            parent_container_item = AnalysisItem(
                FWCaseTableIteratorLogic.source_model, parent_container
            )
        parent_container_item.refresh_files()

        # Parse through uploaded files
        for cache_file in uploaded_files:
            cache_file = Path(cache_file)
            if cache_file.exists():
                # Ensure that the container and the parent item have it
                file_obj = parent_container.get_file(cache_file.name)
                file_items = [
                    parent_container_item.files_folder_item.child(i)
                    for i in range(parent_container_item.files_folder_item.rowCount())
                    if parent_container_item.files_folder_item.child(i).file.name
                    == cache_file.name
                ]
                if file_obj and file_items:
                    # If container and parent item have the file
                    # create the directory, copy, and cache.
                    file_item = file_items[0]
                    file_path = file_item._get_cache_path()
                    file_path.parents[0].mkdir(parents=True, exist_ok=True)
                    shutil.copy(cache_file, file_path)
                    _, _ = file_item._add_to_cache()

    def save_mask_to_container(self, mask_node, reader, caseData):
        """Save a mask to the container of the reference image.

        This function uses the container_id attribute of the reference image node to
        save to the necessary container.

        Args:
            mask_node (Node): Slicer Node of the mask object.
            reader (str): The reader that is doing the segmenting or None.
            caseData (dict): A dictionary representing the VolumeNodes of this case.
        """
        # Get the bounds of the mask
        bounds = [0.0] * 6
        mask_node.GetBounds(bounds)
        # If the mask node has changed since loading and is not empty, save, else skip
        if (
            mask_node.GetModifiedSinceRead()
            and bounds != [1.0, -1.0] * 3
            and bounds[0] < 1e100
        ):
            # Get the relevant case data:
            im_node, _, _, _ = caseData
            # Get the container_id for the reference volume
            parent_container_id = im_node.GetAttribute("parent_container_id")
            if parent_container_id:
                mask_node.SetAttribute("parent_container_id", parent_container_id)
                parent_container = self.fw_client.get(parent_container_id)
                with tempfile.TemporaryDirectory() as tmp_output_path:
                    output_path = Path(tmp_output_path)
                    uploaded_files = []
                    failed_files = []
                    # Convert the mask node to a labelMap
                    # Save the mask node as a NIfTI file to a temporary directory
                    labelmapVolumeNode = slicer.mrmlScene.AddNewNodeByClass(
                        "vtkMRMLLabelMapVolumeNode"
                    )
                    # TODO: Consider using ExportSegmentsToLabelmapNode to export the
                    #       ColorMap as well.
                    segment_logic = slicer.modules.segmentations.logic()
                    segment_logic.ExportVisibleSegmentsToLabelmapNode(
                        mask_node, labelmapVolumeNode, im_node
                    )

                    # Save the labelmapVolumeNode to a file
                    nodename = mask_node.GetName()

                    if reader is not None:
                        nodename += "_" + reader
                    file_name = nodename + ".nii.gz"

                    file_path = output_path / file_name
                    slicer.util.saveNode(labelmapVolumeNode, str(file_path))
                    slicer.mrmlScene.RemoveNode(labelmapVolumeNode)
                    # Upload that file to the container
                    try:
                        parent_container.upload_file(str(file_path))
                        uploaded_files.append(file_path)
                        mask_node.SetAttribute("name", file_name)
                    except Exception as exc:
                        failed_files.append(file_path)

                        self.logger.exception(exc)
                        self.logger.error(
                            "The file, %s, was not uploaded to Flywheel.", file_path
                        )
                    # Tag the file in the container as being a mask
                    if uploaded_files:
                        parent_container = parent_container.reload()
                        new_file = parent_container.get_file(file_path.name)
                        new_file.add_tag("mask")  # TODO: Do we want this anymore?

                    # on success, instantiate that file in the cache_dir for reference
                    self.cache_uploaded_files(parent_container, uploaded_files)
            else:
                self.logger.info(
                    "There is no container associated with "
                    "the reference image, skipping saving."
                )
        else:
            self.logger.info("The mask has not changed, skipping saving.")

    # ------------------------------------------------------------------------------
    def saveMask(self, mask_node, reader, caseData, overwrite_existing=False):
        """Save mask to filesystem.

        This function is not used in this module. It can safely be deleted.

        Args:
            mask_node (Node): Node of mask to save.
            reader (str): Name of the reader or None.
            caseData (dict): Dictionary of the NodeIDs used in this case.
            overwrite_existing (bool, optional): Overwrite existing masks.
                                                 Defaults to False.
        """
        storage_node = mask_node.GetStorageNode()
        if storage_node is not None and storage_node.GetFileName() is not None:
            # mask was loaded, save the updated mask in the same directory
            target_dir = os.path.dirname(storage_node.GetFileName())
        else:
            im_node, _, _, _ = caseData
            target_dir = os.path.dirname(im_node.GetStorageNode().GetFileName())

        if not os.path.isdir(target_dir):
            self.logger.debug("Creating output directory at %s", target_dir)
            os.makedirs(target_dir)

        nodename = mask_node.GetName()

        if reader is not None:
            nodename += "_" + reader
        filename = os.path.join(target_dir, nodename)

        # Prevent overwriting existing files
        if os.path.exists(filename + ".seg.nrrd") and not overwrite_existing:
            self.logger.debug("Filename exists! Generating unique name...")
            idx = 1
            filename += "(%d).seg.nrrd"
            while os.path.exists(filename % idx):
                idx += 1
            filename = filename % idx
        else:
            filename += ".seg.nrrd"

        # Save the mask_node
        slicer.util.saveNode(mask_node, filename)
        self.logger.info("Saved mask node %s in %s", nodename, filename)
