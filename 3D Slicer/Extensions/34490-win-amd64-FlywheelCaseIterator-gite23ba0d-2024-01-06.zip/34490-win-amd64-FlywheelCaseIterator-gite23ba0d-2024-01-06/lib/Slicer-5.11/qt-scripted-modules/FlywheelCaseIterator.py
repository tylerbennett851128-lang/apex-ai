"""# =========================================================================.

#  Copyright Joost van Griethuysen
#
#  Licensed under the 3-Clause BSD-License (the "License");
#  you may not use this file except in compliance with the License.
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
# ========================================================================

# =========================================================================
# This file is adapted from Slicer Case Iterator and is maintained by Flywheel.
#
# The original author, Joost van Griethuysen, is not responsible for any
# changes made to this file or any problems with its use.
#
# Likewise, Flywheel is not responsible for maintaining the original or changes
# that may occur.
# =========================================================================
"""
import importlib
import json
import logging
from collections import deque
from pathlib import Path

import ctk
import qt
import slicer

# fmt: off
# Check for and install missing requirements
source_dir = Path(__file__).parent
resource_dir = source_dir / "Resources"
REQUIRED_MODULES = json.load((resource_dir / "required_modules.json").open())

if not importlib.util.find_spec("fw_pyqt_management"):
    slicer.util.pip_install("fw-pyqt-management")
    
from fw_pyqt_management.utils import check_developer_mode, check_requirements

check_requirements(REQUIRED_MODULES)

# fmt: on

from FlywheelCaseIteratorLib.CsvFWTableIterator import FWCaseTableIteratorLogic
from FlywheelCaseIteratorLib.IteratorFactory import IteratorFactory
from slicer.ScriptedLoadableModule import (
    ScriptedLoadableModule,
    ScriptedLoadableModuleLogic,
    ScriptedLoadableModuleWidget,
)


# ------------------------------------------------------------------------------
# FlywheelCaseIterator
# ------------------------------------------------------------------------------
class FlywheelCaseIterator(ScriptedLoadableModule):
    """Uses ScriptedLoadableModule base class, available at.

    https://github.com/Slicer/Slicer/blob/master/Base/Python/slicer/ScriptedLoadableModule.py
    """

    def __init__(self, parent):
        """Initialize FlywheelCaseIterator.

        Args:
            parent (qSlicerScriptedLoadableModule): The parent of the initialized Extension.
        """
        ScriptedLoadableModule.__init__(self, parent)
        self.parent.title = "Flywheel Case Iterator"
        self.parent.categories = ["Flywheel"]
        self.parent.dependencies = []
        self.parent.contributors = [
            "Joost van Griethuysen (AVL-NKI), "
            "Christian Herz (CHOP), "
            "Joshua Jacobs (Flywheel)"
        ]
        self.parent.helpText = """
          FlywheelCaseIterator is an extension for Slicer that allows users to
          conveniently iterate through NIfTI images from Flywheel. It offers
          functionalities such as creating, reviewing, and updating segmentations on
          these images. The extension also enables easy uploading of NIfTI mask outputs
          back into Flywheel for efficient data management.
          FlywheelCaseIterator is a customized version of the SlicerCaseIterator
          developed by Joost van Griethuysen.
          For more information about Flywheel, a comprehensive data management solution
          for life sciences and imaging research, you can visit their website:
          https://flywheel.io/."
          """
        self.parent.acknowledgementText = """
        This work is covered by the 3-clause BSD License.
        No funding was received for this work.
        """


# ------------------------------------------------------------------------------
# FlywheelCaseIteratorWidget
# ------------------------------------------------------------------------------
class FlywheelCaseIteratorWidget(ScriptedLoadableModuleWidget):
    """Uses ScriptedLoadableModuleWidget base class, available at.

    https://github.com/Slicer/Slicer/blob/master/Base/Python/slicer/ScriptedLoadableModule.py
    """

    def __del__(self):
        """Delete the logic and input widget."""
        self.logger.debug("Destroying Slicer Case Iterator Widget")
        self.logic = None
        self.inputWidget = None
        self._disconnectHandlers()

    def onReload(self):
        """Perform the following when reloading the main Widget."""
        if hasattr(self, "inputWidget"):
            self.inputWidget = None

        IteratorFactory.reloadSourceFiles()
        ScriptedLoadableModuleWidget.onReload(self)

    def setup(self):
        """Perform the following when setting up the main Widget."""
        super().setup()
        check_developer_mode()
        # #################Declare form elements#######################

        self.setupViewSettingsArea()

        # Setup a logger for the extension log messages
        self.logger = logging.getLogger("FlywheelCaseIterator")

        self.logic = None

        # These variables hold connections to other parts of Slicer,
        # such as registered keyboard shortcuts and
        # Event observers
        self.shortcuts = []
        self.observers = []

        # Instantiate and connect widgets ...

        #
        # ComboBox for mode selection
        #
        self.modeGroup = qt.QGroupBox("Mode Selection")
        self.modeGroup.setLayout(qt.QFormLayout())
        self.layout.addWidget(self.modeGroup)

        modes = IteratorFactory.getImplementationNames()

        self.modeComboBox = qt.QComboBox()
        self.modeComboBox.addItems([""] + modes)
        self.modeGroup.layout().addWidget(self.modeComboBox)

        #
        # Select and Load input data section
        #
        self.inputDataCollapsibleButton = ctk.ctkCollapsibleButton()
        self.inputDataCollapsibleButton.text = "Select and Load case data"
        self.layout.addWidget(self.inputDataCollapsibleButton)

        #
        # Parameters Area
        #
        self.parametersCollapsibleButton = ctk.ctkCollapsibleButton()
        self.parametersCollapsibleButton.text = "Case iteration parameters"
        self.layout.addWidget(self.parametersCollapsibleButton)

        # Layout within the dummy collapsible button
        parametersFormLayout = qt.QFormLayout(self.parametersCollapsibleButton)

        #
        # Reader Name
        #
        self.txtReaderName = qt.QLineEdit()
        self.txtReaderName.text = ""
        self.txtReaderName.toolTip = (
            "Name of the current reader; if not empty, "
            "this name will be added to the filename "
            "of saved masks"
        )
        parametersFormLayout.addRow("Reader name", self.txtReaderName)

        #
        # Start position
        #
        self.npStart = qt.QSpinBox()
        self.npStart.minimum = 1
        self.npStart.maximum = 999999
        self.npStart.value = 1
        self.npStart.toolTip = "Start position in the CSV file (1 = first patient)"
        parametersFormLayout.addRow("Start position", self.npStart)

        #
        # Visualization Properties
        #
        self.visualizationPropertiesCollapsibleButton = ctk.ctkCollapsibleButton()
        self.visualizationPropertiesCollapsibleButton.text = "Visualization properties"
        self.layout.addWidget(self.visualizationPropertiesCollapsibleButton)

        visualizationPropertiesFormLayout = qt.QVBoxLayout(
            self.visualizationPropertiesCollapsibleButton
        )

        #
        # Mask Groupbox
        #
        self.maskGroup = qt.QGroupBox("Mask")
        self.maskGroup.setLayout(qt.QFormLayout())
        visualizationPropertiesFormLayout.addWidget(self.maskGroup)

        self.sliceFill2DSlider = slicer.qMRMLSliderWidget()
        self.sliceFill2DSlider.minimum = 0.0
        self.sliceFill2DSlider.maximum = 1.0
        self.sliceFill2DSlider.singleStep = 0.1
        self.maskGroup.layout().addRow("Slice 2D fill:", self.sliceFill2DSlider)

        self.sliceOutline2DSlider = slicer.qMRMLSliderWidget()
        self.sliceOutline2DSlider.minimum = 0.0
        self.sliceOutline2DSlider.maximum = 1.0
        self.sliceOutline2DSlider.singleStep = 0.1
        self.sliceOutline2DSlider.value = 1.0
        self.maskGroup.layout().addRow("Slice 2D outline:", self.sliceOutline2DSlider)

        #
        # Progressbar
        #
        self.progressBar = qt.QProgressBar()
        self.progressBar.setFormat("%v/%m")
        self.progressBar.visible = False
        self.layout.addWidget(self.progressBar)

        #
        # Case Button Row
        #
        self.caseButtonWidget = qt.QWidget()
        self.caseButtonWidget.setLayout(qt.QHBoxLayout())
        self.layout.addWidget(self.caseButtonWidget)

        #
        # Reset
        #
        self.resetButton = qt.QPushButton("Start Batch")
        self.resetButton.enabled = False
        self.caseButtonWidget.layout().addWidget(self.resetButton)

        #
        # Previous Case
        #
        self.previousButton = qt.QPushButton("Previous Case")
        self.previousButton.enabled = False
        self.previousButton.toolTip = (
            "(Ctrl+P) Press this button to go to the previous case, "
            "previous new masks are not reloaded"
        )
        self.caseButtonWidget.layout().addWidget(self.previousButton)

        #
        # Load CSV / Next Case
        #
        self.nextButton = qt.QPushButton("Next Case")
        self.nextButton.enabled = False
        self.nextButton.toolTip = "(Ctrl+N) Press this button to go to the next case"
        self.caseButtonWidget.layout().addWidget(self.nextButton)

        #
        # Collapsible Button group for enabling only one at a time
        #
        self.collapsibleButtonGroup = qt.QButtonGroup()
        self.collapsibleButtonGroup.setExclusive(True)
        self.collapsibleButtonGroup.addButton(self.inputDataCollapsibleButton)
        self.collapsibleButtonGroup.addButton(self.parametersCollapsibleButton)
        self.collapsibleButtonGroup.addButton(
            self.visualizationPropertiesCollapsibleButton
        )

        self.layout.addStretch(1)

        #
        # Connect buttons to functions
        #
        self.modeComboBox.currentTextChanged.connect(self.onModeSelected)
        self.previousButton.connect("clicked(bool)", self.onPrevious)
        self.nextButton.connect("clicked(bool)", self.onNext)
        self.resetButton.connect("clicked(bool)", self.onReset)
        self.sliceFill2DSlider.valueChanged.connect(self.updateSegmentationProperties)
        self.sliceOutline2DSlider.valueChanged.connect(
            self.updateSegmentationProperties
        )

        if len(modes) == 1:
            self.modeComboBox.hide()
            self.onModeSelected(modes[0])

        self._setGUIstate(csv_loaded=False)

    def setupViewSettingsArea(self):
        """Setup the view settings area.

        This is only available if the Slicer Development Toolbox is installed.
        """
        try:
            from SlicerDevelopmentToolboxUtils.buttons import (
                CrosshairButton,
                FourUpLayoutButton,
                FourUpTableViewLayoutButton,
            )
            from SlicerDevelopmentToolboxUtils.mixins import ModuleWidgetMixin

            self.fourUpSliceLayoutButton = FourUpLayoutButton()
            self.fourUpSliceTableViewLayoutButton = FourUpTableViewLayoutButton()
            self.crosshairButton = CrosshairButton()
            self.crosshairButton.setSliceIntersectionEnabled(True)

            hbox = ModuleWidgetMixin.createHLayout(
                [
                    self.fourUpSliceLayoutButton,
                    self.fourUpSliceTableViewLayoutButton,
                    self.crosshairButton,
                ]
            )
            self.layout.addWidget(hbox)
        except ModuleNotFoundError:
            logging.info(
                "Skipping (optional) view settings area: "
                "SlicerDevelopmentToolbox was not found which is required "
                "for setting up the view settings area.  "
                "Please Install SlicerDevelopmentToolbox from the extension "
                "manager if you want to make use of it."
            )

    # ------------------------------------------------------------------------------
    def enter(self):
        """Put focus on the input widget, if it exists."""
        if hasattr(self, "inputWidget"):
            self.inputWidget.enter()

    # ------------------------------------------------------------------------------
    def onModeSelected(self, mode):
        """Instantiate the input widget on the selected mode.

        Modes are the keys of IteratorFactory.IMPLEMENTATIONS dictionary.

        Args:
            mode (str): The mode used for the input widget.
        """
        # Setup the widget for CSV table input
        self.inputWidget = IteratorFactory.getIteratorWidget(mode)()
        self.inputWidget.validationHandler = self.onValidateInput

        inputDataFormLayout = qt.QFormLayout(self.inputDataCollapsibleButton)
        self.inputParametersGroupBox = self.inputWidget.setup()
        inputDataFormLayout.addRow(self.inputParametersGroupBox)

        self.modeGroup.hide()
        self.inputDataCollapsibleButton.click()

    # ------------------------------------------------------------------------------
    def onValidateInput(self, is_valid):
        """Enable starting a batch on valid input.

        Args:
            is_valid (bool): Flag denoting valid input.
        """
        self.resetButton.enabled = is_valid

    # ------------------------------------------------------------------------------
    def updateSegmentationProperties(self, value=None):
        """Update the outline and opacity of each segmentation node.

        Args:
            value (float, optional): Value to set. Defaults to None.
        """

        def update(segNode):
            """Update the outline and opacity of the given segmentation node.

            Args:
                segNode (vtkMRMLSegmentationNode): The segmentation node to adjust.
            """
            try:
                segNode.GetDisplayNode().SetOpacity2DFill(self.sliceFill2DSlider.value)
                segNode.GetDisplayNode().SetOpacity2DOutline(
                    self.sliceOutline2DSlider.value
                )
            except AttributeError:
                pass

        deque(map(update, slicer.util.getNodesByClass("vtkMRMLSegmentationNode")))

    # ------------------------------------------------------------------------------
    def onReset(self):
        """Start or reset batch editing.

        If there is an error in starting the batch, the GUI is unlocked.

        """
        if self.logic is None:
            # Start the batch!
            # Lock GUI during loading
            self._unlockGUI(False)

            try:
                reader = self.txtReaderName.text
                if reader == "":
                    reader = None
                iterator = self.inputWidget.startBatch(reader)
                self.logic = FlywheelCaseIteratorLogic(iterator, self.npStart.value)
                self.logic.start()
                self.updateSegmentationProperties()
                self._setGUIstate()
                self._unlockGUI(True)
            except Exception as e:
                if slicer.app.majorVersion * 100 + slicer.app.minorVersion < 411:
                    e = e.message
                self.logger.error("Error loading batch! %s", e)
                self.logger.debug("", exc_info=True)
                self._setGUIstate(csv_loaded=False)

        else:
            # End the batch and clean up
            self.inputWidget.cleanupBatch()
            self.logic = None
            self._setGUIstate(csv_loaded=False)

    # ------------------------------------------------------------------------------
    def onPrevious(self):
        """Executed on press of the "Previous Case" button."""
        # Lock GUI during loading
        self._unlockGUI(False)

        self.logic.previousCase()
        self.progressBar.value = self.logic.currentIdx + 1
        self.updateSegmentationProperties()

        # Unlock GUI
        self._unlockGUI(True)

    # ------------------------------------------------------------------------------
    def onNext(self):
        """Executed on press of the "Next Case" button."""
        # Lock GUI during loading
        self._unlockGUI(False)

        if self.logic.nextCase():
            # Last case processed, reset GUI
            self.onReset()
        else:
            self.progressBar.value = self.logic.currentIdx + 1
            self.updateSegmentationProperties()

        # Unlock GUI
        self._unlockGUI(True)

    # ------------------------------------------------------------------------------
    def _unlockGUI(self, unlocked):
        """Enable or disable controls based on value of "unlocked".

        Args:
            unlocked (boolean): Indicates to enable or disable controls.
        """
        self.previousButton.enabled = unlocked and self.logic is not None
        self.nextButton.enabled = unlocked and self.logic is not None
        self.resetButton.enabled = unlocked
        if unlocked:
            self.nextButton.text = "Next Case"
        else:
            self.nextButton.text = "Loading..."

    # ------------------------------------------------------------------------------
    def _setGUIstate(self, csv_loaded=True):
        """Enables the start of a batch on csv_loaded.

        Args:
            csv_loaded (bool, optional): If CSV is loaded. Defaults to True.
        """
        if csv_loaded:
            self.resetButton.enabled = True
            self.resetButton.text = "Reset"

            self.progressBar.value = self.logic.currentIdx + 1
            self.progressBar.maximum = self.logic.iterator.caseCount
            self._connectHandlers()
        else:
            # reset Button is locked when loading cases,
            # ensure it is unlocked to load new batch
            self.resetButton.enabled = (
                hasattr(self, "inputWidget") and self.inputWidget.is_valid()
            )
            self.resetButton.text = "Start Batch"

            self._disconnectHandlers()

        self.progressBar.visible = csv_loaded
        self.previousButton.enabled = csv_loaded and self.logic is not None
        self.nextButton.enabled = csv_loaded and self.logic is not None

        if hasattr(self, "inputParametersGroupBox"):
            self.inputParametersGroupBox.enabled = not csv_loaded

    # ------------------------------------------------------------------------------
    def _connectHandlers(self):
        """Connect the CTRL + N and CTRL + P Shortcut."""
        if len(self.shortcuts) == 0:
            shortcutNext = qt.QShortcut(slicer.util.mainWindow())
            shortcutNext.setKey(qt.QKeySequence("Ctrl+N"))

            shortcutNext.connect("activated()", self.onNext)
            self.shortcuts.append(shortcutNext)

            shortcutPrevious = qt.QShortcut(slicer.util.mainWindow())
            shortcutPrevious.setKey(qt.QKeySequence("Ctrl+P"))

            shortcutPrevious.connect("activated()", self.onPrevious)
            self.shortcuts.append(shortcutPrevious)
        else:
            self.logger.warning("Shortcuts already initialized!")

    # ------------------------------------------------------------------------------
    def _disconnectHandlers(self):
        """Remove the keyboard shortcuts.

        This is important when the GUI becomes inactive.
        """
        for sc in self.shortcuts:
            sc.disconnect("activated()")
            sc.setParent(None)
        self.shortcuts = []

        # Remove the event observer
        for obs in self.observers:
            slicer.mrmlScene.RemoveObserver(obs)
        self.observers = []


# ------------------------------------------------------------------------------
# FlywheelCaseIteratorLogic
# ------------------------------------------------------------------------------
class FlywheelCaseIteratorLogic(ScriptedLoadableModuleLogic):
    """This class should implement all the actual computation done by your module.

    The interface should be such that other python code can import this class and make
    use of the functionality without requiring an instance of the Widget.
    Uses ScriptedLoadableModuleLogic base class, available at:
    https://github.com/Slicer/Slicer/blob/master/Base/Python/slicer/ScriptedLoadableModule.py
    """

    def __init__(self, iterator, start):
        """Initialize the logic.

        Args:
            iterator (IteratorWidgetBase): The iterator widget being used.
            start (int): The start of the batch (1-based).
        """
        ScriptedLoadableModuleLogic.__init__(self)

        self.logger = logging.getLogger("FlywheelCaseIterator.logic")

        # Iterator class defining the iterable to iterate over cases
        assert isinstance(iterator, FWCaseTableIteratorLogic)
        self.iterator = iterator
        assert (
            self.iterator.caseCount >= start
        ), "No cases to process (%d cases, start %d)" % (self.iterator.caseCount, start)
        self.currentIdx = (
            start - 1
        )  # Current case index (starts at 0 for fist case, -1 means nothing loaded)

    def __del__(self):
        """Delete the iterator."""
        # Free up the references to the nodes to allow GC and prevent memory leaks
        self.logger.debug("Destroying Case Iterator Logic instance")
        self.iterator = None

    def start(self):
        """Load the first case.

        On load failure (e.g. file not found) the current index is incremented and the
        next case is attempted to be loaded.
        """
        try:
            self._loadCase()
        except:
            self.nextCase()

    # ------------------------------------------------------------------------------

    def nextCase(self):
        """Increment the current index and attempt to load the next case.

        On load failure (e.g. file not found) the current index is incremented and the
        next case is attempted to be loaded.

        Returns:
            boolean: True if at or beyond the last case, False otherwise
        """
        self.currentIdx += 1
        return_val = True
        case_loaded = False
        # Loop until the end if case cannot be loaded
        # If the reference image cannot be loaded, try the next case
        while self.currentIdx <= self.iterator.caseCount and not case_loaded:
            try:
                return_val = self._loadCase()
                case_loaded = True
            except:
                self.currentIdx += 1

        return return_val

    def previousCase(self):
        """Decrement the current index and attempt to load the previous case.

        On load failure (e.g. file not found) the current index is decremented and the
        previous case is attempted to be loaded.

        Returns:
            boolean: True if at or beyond the first case, False otherwise
        """
        self.currentIdx -= 1
        return_val = False
        case_loaded = False
        # Loop until the beginning if case cannot be loaded
        # If the reference image cannot be loaded, try the previous case
        while self.currentIdx >= -1 and not case_loaded:
            try:
                return_val = self._loadCase()
                case_loaded = True
            except:
                self.currentIdx -= 1
                # If the start of the batch cannot be loaded, break out of loop
                if self.currentIdx < 0:
                    self.currentIdx = 0
                    break

        return return_val

    def _loadCase(self):
        """Load the case at the current index.

        If a current case is open, it is saved if necessary and then closed.
        Next, a new case is obtained from the iterator, which is then loaded as the new
        ``currentCase``.

        If the last case was loaded, the iterator exits and resets the GUI to allow
        for loading a new batch of cases.

        Returns:
            boolean: True if the end of the batch is reached, otherwise False.
        """
        if self.currentIdx < 0:
            self.currentIdx = 0
            # Cannot select a negative index, so give a warning and exit the function
            self.logger.warning("First case selected, cannot select previous case!")
            return False

        if self.iterator.currentIdx is not None:
            self._closeCase()

        if self.currentIdx >= self.iterator.caseCount:
            self.logger.info("########## All Done! ##########")
            return True

        self.iterator.loadCase(self.currentIdx)

        return False

    def _closeCase(self):
        """Close the current case in the current iterator."""
        self.iterator.closeCase()
