# BioZ V0.1 Starter

A bench-only starter package for a multi-frequency bioimpedance measurement prototype based on:

- EVAL-ADICUP3029
- EVAL-AD5940BIOZ
- Analog Devices `ad5940-examples`
- The official `AD5940_BIA` application layer

## Important safety boundary

This package is for measurements of known resistors, resistor-capacitor networks, and the
AD5940 Z test board. It is not patient-ready firmware.

Do not connect the unmodified evaluation hardware to a person. Complete electrical-safety,
isolation, current-limit, leakage-current, EMC, and risk-management work before any human study.

## Directory layout

```text
bioz_v01_starter/
├── firmware/
│   ├── AD5940Main_v01.c
│   └── v01_config.h
├── host/
│   ├── capture_and_plot.py
│   └── requirements.txt
├── sample/
│   └── rc_sweep.csv
└── docs/
    └── block_diagram.md
```

## Firmware integration

1. Clone Analog Devices' official `ad5940-examples` repository recursively.
2. Open `examples/AD5940_BIA`.
3. Keep the official:
   - `BodyImpedance.c`
   - `BodyImpedance.h`
   - `ad5940lib`
   - ADICUP3029 or NUCLEO hardware-port files
4. Add `firmware/v01_config.h`.
5. Replace the example application's `AD5940Main.c` with `firmware/AD5940Main_v01.c`.
6. Build using one of the official board projects.

The firmware prints CSV rows over UART:

```text
BIOZ,sample_id,frequency_hz,magnitude_ohm,phase_deg,real_ohm,imag_ohm
```

## Host application

Install:

```bash
python -m pip install -r host/requirements.txt
```

Read an existing CSV file:

```bash
python host/capture_and_plot.py --file sample/rc_sweep.csv
```

Capture from a serial port:

```bash
python host/capture_and_plot.py --port COM5 --baud 115200 --output measured.csv
```

## V0.1 acceptance test

Use known loads and confirm:

- each requested frequency is reported;
- magnitude tracks the expected impedance;
- phase tracks the expected impedance;
- repeated sweeps are stable;
- open/short/invalid loads are flagged by your test procedure;
- results are stored as raw numeric data, not health diagnoses.

This package intentionally contains no hydration, disease, organ, vitamin, glucose, or
tuberculosis prediction model.
