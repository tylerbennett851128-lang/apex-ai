/*
 * BioZ V0.1 bench firmware wrapper.
 *
 * Dependencies:
 *   - Analog Devices ad5940lib
 *   - examples/AD5940_BIA/BodyImpedance.c
 *   - examples/AD5940_BIA/BodyImpedance.h
 *   - the official MCU hardware-port implementation
 *
 * Bench loads only. Do not connect the unmodified evaluation board to a person.
 */

#include <math.h>
#include <stdint.h>
#include <stdio.h>

#include "ad5940.h"
#include "AD5940.h"
#include "BodyImpedance.h"
#include "v01_config.h"

#ifndef MATH_PI
#define MATH_PI 3.14159265358979323846f
#endif

static uint32_t g_app_buffer[BIOZ_APP_BUFFER_WORDS];
static uint32_t g_sample_id = 0u;

static int32_t platform_configure(void)
{
    CLKCfg_Type clock_cfg = {0};
    FIFOCfg_Type fifo_cfg = {0};
    AGPIOCfg_Type gpio_cfg = {0};

    AD5940_HWReset();
    AD5940_Initialize();

    clock_cfg.ADCClkDiv = ADCCLKDIV_1;
    clock_cfg.ADCCLkSrc = ADCCLKSRC_HFOSC;
    clock_cfg.SysClkDiv = SYSCLKDIV_1;
    clock_cfg.SysClkSrc = SYSCLKSRC_HFOSC;
    clock_cfg.HfOSC32MHzMode = bFALSE;
    clock_cfg.HFOSCEn = bTRUE;
    clock_cfg.HFXTALEn = bFALSE;
    clock_cfg.LFOSCEn = bTRUE;
    AD5940_CLKCfg(&clock_cfg);

    /* Reset FIFO first, then enable DFT results. */
    fifo_cfg.FIFOEn = bFALSE;
    fifo_cfg.FIFOMode = FIFOMODE_FIFO;
    fifo_cfg.FIFOSize = FIFOSIZE_4KB;
    fifo_cfg.FIFOSrc = FIFOSRC_DFT;
    fifo_cfg.FIFOThresh = 4u;
    AD5940_FIFOCfg(&fifo_cfg);

    fifo_cfg.FIFOEn = bTRUE;
    AD5940_FIFOCfg(&fifo_cfg);

    AD5940_INTCCfg(AFEINTC_1, AFEINTSRC_ALLINT, bTRUE);
    AD5940_INTCCfg(AFEINTC_0, AFEINTSRC_DATAFIFOTHRESH, bTRUE);
    AD5940_INTCClrFlag(AFEINTSRC_ALLINT);

    gpio_cfg.FuncSet =
        GP6_SYNC | GP5_SYNC | GP4_SYNC | GP2_TRIG | GP1_SYNC | GP0_INT;
    gpio_cfg.InputEnSet = AGPIO_Pin2;
    gpio_cfg.OutputEnSet =
        AGPIO_Pin0 | AGPIO_Pin1 | AGPIO_Pin4 | AGPIO_Pin5 | AGPIO_Pin6;
    gpio_cfg.OutVal = 0u;
    gpio_cfg.PullEnSet = 0u;
    AD5940_AGPIOCfg(&gpio_cfg);

    AD5940_SleepKeyCtrlS(SLPKEY_UNLOCK);
    return 0;
}

static int32_t configure_bia_application(void)
{
    AppBIACfg_Type *cfg = NULL;

    if (AppBIAGetCfg(&cfg) != AD5940ERR_OK || cfg == NULL) {
        return -1;
    }

    cfg->bParaChanged = bTRUE;
    cfg->SeqStartAddr = 0u;
    cfg->MaxSeqLen = 512u;

    cfg->RcalVal = BIOZ_RCAL_OHM;
    cfg->DacVoltPP = BIOZ_DAC_MV_PP;
    cfg->DftNum = DFTNUM_8192;
    cfg->NumOfData = -1;
    cfg->BiaODR = BIOZ_OUTPUT_RATE_HZ;
    cfg->FifoThresh = 4u;
    cfg->ADCSinc3Osr = ADCSINC3OSR_2;

    cfg->SinFreq = BIOZ_SWEEP_START_HZ;
    cfg->SweepCfg.SweepEn = bTRUE;
    cfg->SweepCfg.SweepStart = BIOZ_SWEEP_START_HZ;
    cfg->SweepCfg.SweepStop = BIOZ_SWEEP_STOP_HZ;
    cfg->SweepCfg.SweepPoints = BIOZ_SWEEP_POINTS;
    cfg->SweepCfg.SweepLog = BIOZ_SWEEP_LOGARITHMIC;
    cfg->SweepCfg.SweepIndex = 0u;

    return 0;
}

static void emit_results(uint32_t *data, uint32_t count)
{
    float frequency_hz = 0.0f;
    fImpPol_Type *results = (fImpPol_Type *)data;

    if (AppBIACtrl(BIACTRL_GETFREQ, &frequency_hz) != AD5940ERR_OK) {
        printf("ERROR,get_frequency_failed\r\n");
        return;
    }

    for (uint32_t i = 0u; i < count; ++i) {
        const float magnitude = results[i].Magnitude;
        const float phase_rad = results[i].Phase;
        const float phase_deg = phase_rad * 180.0f / MATH_PI;
        const float real_ohm = magnitude * cosf(phase_rad);
        const float imag_ohm = magnitude * sinf(phase_rad);

        printf(
            "BIOZ,%lu,%.3f,%.6f,%.6f,%.6f,%.6f\r\n",
            (unsigned long)g_sample_id++,
            frequency_hz,
            magnitude,
            phase_deg,
            real_ohm,
            imag_ohm
        );
    }
}

void AD5940_Main(void)
{
    uint32_t result_count;
    AD5940Err error;

    printf(
        "INFO,bioz_v01,start_hz=%.1f,stop_hz=%.1f,points=%u,rcal_ohm=%.1f\r\n",
        BIOZ_SWEEP_START_HZ,
        BIOZ_SWEEP_STOP_HZ,
        (unsigned)BIOZ_SWEEP_POINTS,
        BIOZ_RCAL_OHM
    );

    if (platform_configure() != 0) {
        printf("ERROR,platform_configure_failed\r\n");
        return;
    }

    if (configure_bia_application() != 0) {
        printf("ERROR,bia_configuration_failed\r\n");
        return;
    }

    error = AppBIAInit(g_app_buffer, BIOZ_APP_BUFFER_WORDS);
    if (error != AD5940ERR_OK) {
        printf("ERROR,bia_init_failed,%ld\r\n", (long)error);
        return;
    }

    error = AppBIACtrl(BIACTRL_START, NULL);
    if (error != AD5940ERR_OK) {
        printf("ERROR,bia_start_failed,%ld\r\n", (long)error);
        return;
    }

    for (;;) {
        if (!AD5940_GetMCUIntFlag()) {
            continue;
        }

        AD5940_ClrMCUIntFlag();
        result_count = BIOZ_APP_BUFFER_WORDS;

        error = AppBIAISR(g_app_buffer, &result_count);
        if (error != AD5940ERR_OK) {
            printf("ERROR,bia_isr_failed,%ld\r\n", (long)error);
            continue;
        }

        if (result_count > 0u) {
            emit_results(g_app_buffer, result_count);
        }
    }
}
