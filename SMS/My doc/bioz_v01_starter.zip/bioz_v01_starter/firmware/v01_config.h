#ifndef BIOZ_V01_CONFIG_H
#define BIOZ_V01_CONFIG_H

/* Bench-only sweep configuration. */
#define BIOZ_SWEEP_START_HZ       5000.0f
#define BIOZ_SWEEP_STOP_HZ      100000.0f
#define BIOZ_SWEEP_POINTS             16u
#define BIOZ_SWEEP_LOGARITHMIC     bTRUE

/* Match this to the physical RCAL fitted on your board. */
#define BIOZ_RCAL_OHM           10000.0f

/* Conservative bench excitation; not a declaration of patient safety. */
#define BIOZ_DAC_MV_PP            200.0f

#define BIOZ_OUTPUT_RATE_HZ          5.0f
#define BIOZ_APP_BUFFER_WORDS        512u

#endif
