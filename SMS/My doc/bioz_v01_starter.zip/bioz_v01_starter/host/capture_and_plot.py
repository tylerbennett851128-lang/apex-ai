#!/usr/bin/env python3
"""Capture and plot BioZ V0.1 CSV output."""

from __future__ import annotations

import argparse
import csv
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, TextIO

import matplotlib.pyplot as plt


@dataclass(frozen=True)
class BiozRow:
    sample_id: int
    frequency_hz: float
    magnitude_ohm: float
    phase_deg: float
    real_ohm: float
    imag_ohm: float


def parse_bioz_line(line: str) -> BiozRow | None:
    parts = [part.strip() for part in line.strip().split(",")]
    if len(parts) != 7 or parts[0] != "BIOZ":
        return None

    try:
        return BiozRow(
            sample_id=int(parts[1]),
            frequency_hz=float(parts[2]),
            magnitude_ohm=float(parts[3]),
            phase_deg=float(parts[4]),
            real_ohm=float(parts[5]),
            imag_ohm=float(parts[6]),
        )
    except ValueError:
        return None


def read_rows(stream: Iterable[str]) -> list[BiozRow]:
    rows: list[BiozRow] = []
    for line in stream:
        row = parse_bioz_line(line)
        if row is not None:
            rows.append(row)
    return rows


def write_csv(path: Path, rows: list[BiozRow]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "sample_id",
                "frequency_hz",
                "magnitude_ohm",
                "phase_deg",
                "real_ohm",
                "imag_ohm",
            ]
        )
        for row in rows:
            writer.writerow(
                [
                    row.sample_id,
                    row.frequency_hz,
                    row.magnitude_ohm,
                    row.phase_deg,
                    row.real_ohm,
                    row.imag_ohm,
                ]
            )


def load_csv(path: Path) -> list[BiozRow]:
    rows: list[BiozRow] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for item in reader:
            rows.append(
                BiozRow(
                    sample_id=int(item["sample_id"]),
                    frequency_hz=float(item["frequency_hz"]),
                    magnitude_ohm=float(item["magnitude_ohm"]),
                    phase_deg=float(item["phase_deg"]),
                    real_ohm=float(item["real_ohm"]),
                    imag_ohm=float(item["imag_ohm"]),
                )
            )
    return rows


def capture_serial(port: str, baud: int, max_rows: int) -> list[BiozRow]:
    try:
        import serial
    except ImportError as exc:
        raise RuntimeError(
            "pyserial is required for serial capture. "
            "Install host/requirements.txt."
        ) from exc

    rows: list[BiozRow] = []
    with serial.Serial(port, baudrate=baud, timeout=1.0) as device:
        print(f"Capturing from {port} at {baud} baud...", file=sys.stderr)
        while len(rows) < max_rows:
            raw = device.readline()
            if not raw:
                continue
            line = raw.decode("utf-8", errors="replace").strip()
            print(line)
            row = parse_bioz_line(line)
            if row is not None:
                rows.append(row)
    return rows


def plot_rows(rows: list[BiozRow]) -> None:
    if not rows:
        raise ValueError("No valid BioZ rows were found.")

    # Keep the most recent value at each frequency.
    latest: dict[float, BiozRow] = {}
    for row in rows:
        latest[row.frequency_hz] = row

    ordered = [latest[freq] for freq in sorted(latest)]
    freq = [row.frequency_hz for row in ordered]
    magnitude = [row.magnitude_ohm for row in ordered]
    phase = [row.phase_deg for row in ordered]

    plt.figure()
    plt.semilogx(freq, magnitude, marker="o")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Magnitude (ohm)")
    plt.title("BioZ magnitude spectrum")
    plt.grid(True)

    plt.figure()
    plt.semilogx(freq, phase, marker="o")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Phase (degree)")
    plt.title("BioZ phase spectrum")
    plt.grid(True)

    plt.show()


def main() -> int:
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--file", type=Path, help="Read a saved CSV file.")
    source.add_argument("--port", help="Capture the firmware CSV stream.")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--max-rows", type=int, default=64)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    if args.file is not None:
        rows = load_csv(args.file)
    else:
        rows = capture_serial(args.port, args.baud, args.max_rows)
        if args.output is not None:
            write_csv(args.output, rows)

    plot_rows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
