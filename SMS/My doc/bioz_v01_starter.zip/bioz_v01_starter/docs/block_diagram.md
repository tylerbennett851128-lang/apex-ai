# BioZ V0.1 block diagram

```text
 Known R/C load or AD5940 Z test board
                 │
       F+ ───────┼─────── F−
       S+ ───────┼─────── S−
                 │
┌────────────────▼────────────────┐
│ EVAL-AD5940BIOZ                 │
│                                │
│ • isolation capacitors         │
│ • current-limiting resistors    │
│ • AD5940 waveform generator     │
│ • switch matrix                 │
│ • differential voltage path     │
│ • current/TIA path              │
│ • ADC + DFT + FIFO              │
└────────────────┬────────────────┘
                 │ SPI + interrupt
┌────────────────▼────────────────┐
│ EVAL-ADICUP3029 / supported MCU │
│                                │
│ • sweep controller              │
│ • RCAL-based calibration        │
│ • magnitude/phase calculation   │
│ • CSV output                    │
└────────────────┬────────────────┘
                 │ UART / USB
┌────────────────▼────────────────┐
│ PC research application         │
│                                │
│ • capture raw results           │
│ • save CSV                      │
│ • magnitude-vs-frequency plot   │
│ • phase-vs-frequency plot       │
│ • repeatability comparison      │
└─────────────────────────────────┘
```

## V0.1 boundary

Input: known electrical test loads.

Output: calibrated complex impedance spectrum.

Not included: a human connection, health diagnosis, disease prediction, or treatment advice.
